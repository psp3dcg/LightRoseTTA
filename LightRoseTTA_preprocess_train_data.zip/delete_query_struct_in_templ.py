# import os
# import sys



# def delete_struct_in_hhr(file_path, write_path, protein_name):
# 	with open(file_path) as f:
# 		hhr_file = f.readlines()

# 	new_hhr_file = []
# 	delete_protein_number = []
# 	del_flag = False
# 	for line in hhr_file:
# 		if line[:10] == 'Confidence':
# 			del_flag = False
# 			continue

# 		if line[4:8] == protein_name:
# 			delete_protein_number.append(int(line[:3]))
# 			continue

# 		if line[:3] == 'No ' and int(line[3:]) in delete_protein_number:
# 			del_flag = True

# 		if del_flag:
# 			continue



# 		new_hhr_file.append(line)

# 	with open(write_path, 'w') as f:
# 		for line in new_hhr_file:
# 			f.write(line)

# def delete_struct_in_atab(file_path, write_path, protein_name):
# 	with open(file_path) as f:
# 		atab_file = f.readlines()

# 	new_atab_file = []
# 	del_flag = False
# 	for line in atab_file:
# 		if line[:1] == '>':
# 			del_flag = False

# 		if line[1:5] == protein_name:
# 			del_flag = True
# 			continue

# 		if del_flag:
# 			continue

# 		new_atab_file.append(line)

# 	with open(write_path, 'w') as f:
# 		for line in new_atab_file:
# 			f.write(line)


# def main():

# 	# protein_name = "1lq7"
# 	# file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.hhr"
# 	# write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.hhr"

# 	# delete_struct_in_hhr(file_path, write_path, protein_name)

# 	# file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.atab"
# 	# write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.atab"

# 	# delete_struct_in_atab(file_path, write_path, protein_name)

# 	# file_path = "/data/wxd_workspace/LightFold/LightFold-code/Design55_2020_data/raw/"
# 	# write_path = "/data/wxd_workspace/LightFold/LightFold-code/Design55_2020_data/raw/"
# 	# for name in os.listdir(file_path):
# 	# 	print(name)
# 	# 	protein_name = name.split('_')[0].lower()
# 	# 	hhr_path = os.path.join(file_path, name, "t000_.hhr")
# 	# 	new_hhr_path = os.path.join(file_path, name, "t000_new_.hhr")
# 	# 	delete_struct_in_hhr(hhr_path, new_hhr_path, protein_name)

# 	# 	atab_path = os.path.join(file_path, name, "t000_.atab")
# 	# 	new_atab_path = os.path.join(file_path, name, "t000_new_.atab")
# 	# 	delete_struct_in_atab(atab_path, new_atab_path, protein_name)

# 	# file_path = "/data/dataset/Orphan_data/raw"
# 	# write_path = "/data/dataset/Orphan_data/raw"
# 	file_path = sys.argv[1]
# 	write_path = sys.argv[2]
# 	name_dict = {'T1025':'6uv6',
# 				'T1028':'6vqp',
# 				'T1036s1':'6vn1',
# 				'T1044':'6vr4',
# 				'T1045s1':'6xod',
# 				'T1048':'6un9',
# 				'T1059':'7th8',
# 				'T1060s2':'7qg9',
# 				'T1060s3':'7qg9',
# 				'T1061':'7zhj',
# 				'T1062':'7zhj',
# 				'T1072s1':'6r17',
# 				'T1072s2':'6hk8',
# 				'T1074':'7oc9',
# 				'T1076':'6xn8',
# 				'T1078':'7cwp',
# 				'T1096':'7um1'}
# 	for name in os.listdir(file_path):
# 		print(name)
# 		# protein_name = name_dict[name]
# 		protein_name = name.split('_')[0].lower()
# 		hhr_path = os.path.join(file_path, name, "t000_.hhr")
# 		mid_hhr_path = os.path.join(file_path, name, "t000_old.hhr")
# 		os.rename(hhr_path, mid_hhr_path)
# 		new_hhr_path = os.path.join(file_path, name, "t000_.hhr")
# 		delete_struct_in_hhr(mid_hhr_path, new_hhr_path, protein_name)

# 		atab_path = os.path.join(file_path, name, "t000_.atab")
# 		mid_atab_path = os.path.join(file_path, name, "t000_old.atab")
# 		os.rename(atab_path, mid_atab_path)
# 		new_atab_path = os.path.join(file_path, name, "t000_.atab")
# 		delete_struct_in_atab(mid_atab_path, new_atab_path, protein_name)

# if __name__ == '__main__':
# 	main()


# import os

# file_path = '/data3/protein/datasets/Design_pure_data'
# for name in os.listdir(file_path):
# 	print(name)
# 	hhr_path = os.path.join(file_path, name, 't000_.hhr')
# 	hhr_new_path = os.path.join(file_path, name, 't000_woss.hhr')
# 	atab_path = os.path.join(file_path, name, 't000_.atab')
# 	atab_new_path = os.path.join(file_path, name, 't000_woss.atab')
# 	os.rename(hhr_path, hhr_new_path)
# 	os.rename(atab_path, atab_new_path)



import os
import sys



def delete_struct_in_hhr(file_path, write_path, protein_name):
        with open(file_path) as f:
                hhr_file = f.readlines()

        new_hhr_file = []
        delete_protein_number = []
        del_flag = False
        for line in hhr_file:
                if line[4:8] == protein_name:
                        delete_protein_number.append(int(line[:3]))
                        continue

                if line[:3] == 'No ':
                        if int(line[3:]) in delete_protein_number:
                                del_flag = True
                        else:
                                del_flag = False
                if del_flag:
                        continue



                new_hhr_file.append(line)

        with open(write_path, 'w') as f:
                for line in new_hhr_file:
                        f.write(line)

def delete_struct_in_atab(file_path, write_path, protein_name):
        with open(file_path) as f:
                atab_file = f.readlines()

        new_atab_file = []
        del_flag = False
        for line in atab_file:
                if line[:1] == '>':
                        del_flag = False

                if line[1:5] == protein_name:
                        del_flag = True
                        continue

                if del_flag:
                        continue

                new_atab_file.append(line)

        with open(write_path, 'w') as f:
                for line in new_atab_file:
                        f.write(line)


def main():

        # protein_name = "1lq7"
        # file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.hhr"
        # write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.hhr"

        # delete_struct_in_hhr(file_path, write_path, protein_name)

        # file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.atab"
        # write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.atab"

        # delete_struct_in_atab(file_path, write_path, protein_name)

        # file_path = "/data/wxd_workspace/LightFold/LightFold-code/Design55_2020_data/raw/"
        # write_path = "/data/wxd_workspace/LightFold/LightFold-code/Design55_2020_data/raw/"
        # for name in os.listdir(file_path):
        #       print(name)
        #       protein_name = name.split('_')[0].lower()
        #       hhr_path = os.path.join(file_path, name, "t000_.hhr")
        #       new_hhr_path = os.path.join(file_path, name, "t000_new_.hhr")
        #       delete_struct_in_hhr(hhr_path, new_hhr_path, protein_name)

        #       atab_path = os.path.join(file_path, name, "t000_.atab")
        #       new_atab_path = os.path.join(file_path, name, "t000_new_.atab")
        #       delete_struct_in_atab(atab_path, new_atab_path, protein_name)

        # file_path = "/data/dataset/Orphan_data/raw"
        # write_path = "/data/dataset/Orphan_data/raw"
        file_path = sys.argv[1]
        write_path = sys.argv[2]
        name_dict = {'T1025':'6uv6',
                                'T1028':'6vqp',
                                'T1036s1':'6vn1',
                                'T1044':'6vr4',
                                'T1045s1':'6xod',
                                'T1048':'6un9',
                                'T1059':'7th8',
                                'T1060s2':'7qg9',
                                'T1060s3':'7qg9',
                                'T1061':'7zhj',
                                'T1062':'7zhj',
                                'T1072s1':'6r17',
                                'T1072s2':'6hk8',
                                'T1074':'7oc9',
                                'T1076':'6xn8',
                                'T1078':'7cwp',
                                'T1096':'7um1'}
        for name in os.listdir(file_path):
                print(name)
                #protein_name = name_dict[name]
                protein_name = name.split('_')[0].lower()
                hhr_path = os.path.join(file_path, name, "t000_.hhr")
                mid_hhr_path = os.path.join(file_path, name, "t000_old3.hhr")
                os.rename(hhr_path, mid_hhr_path)
                new_hhr_path = os.path.join(file_path, name, "t000_.hhr")
                delete_struct_in_hhr(mid_hhr_path, new_hhr_path, protein_name)

                atab_path = os.path.join(file_path, name, "t000_.atab")
                mid_atab_path = os.path.join(file_path, name, "t000_old3.atab")
                os.rename(atab_path, mid_atab_path)
                new_atab_path = os.path.join(file_path, name, "t000_.atab")
                delete_struct_in_atab(mid_atab_path, new_atab_path, protein_name)

if __name__ == '__main__':
        main()

