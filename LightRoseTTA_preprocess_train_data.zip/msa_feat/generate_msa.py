import sys
import os
import time
import codecs
import pdb
from tqdm import tqdm
from multiprocessing import Pool
from msa_feat.generate_ncaccb import ncaccb_process
from msa_feat.generate_dis_angle import dis_angle_process
from msa_feat.delete_query_struct_in_templ import delete_struct_in_hhr
from msa_feat.delete_query_struct_in_templ import delete_struct_in_atab

# from generate_ncaccb import ncaccb_process
# from generate_dis_angle import dis_angle_process
# from delete_query_struct_in_templ import delete_struct_in_hhr
# from delete_query_struct_in_templ import delete_struct_in_atab

def check_fasta(input_f):
    lines = [i.strip() for i in open(input_f)]
    return len(lines) > 1 and lines[1] != ''
def process(input_path, ouput_base_dir, pdb_name, seq_search_db, big_seq_search_db, templ_search_db):

    if not os.path.exists(input_path):
        return
    if not check_fasta(input_path):
        return
    output_dir = os.path.join(ouput_base_dir, pdb_name)

    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    cmd = "bash msa_feat/run_generate_feat.sh %s %s %s %s %s" % (input_path, output_dir, seq_search_db, big_seq_search_db, templ_search_db)
    
    os.system(cmd)
    # remove useless file
    hh_folder = os.path.join(output_dir, "hhblits")
    log_folder = os.path.join(output_dir, "log")
    if os.path.exists(hh_folder):
        os.system("rm -r {:}".format(hh_folder))
    if os.path.exists(log_folder):
        os.system("rm -r {:}".format(log_folder))
    print("generate {:} done".format(pdb_name))


def extract_msa_templ_func(fasta_dir, fasta_name, output_base_dir, seq_search_db, templ_search_db, index):
    hhr_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_.hhr")
    atab_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_.atab")
    import pdb
    pdb.set_trace()
    print('extract %d protein %s'%(index, fasta_name))
    if not (os.path.exists(hhr_path) and os.path.exists(atab_path)):
        print(fasta_name.split('.')[0])
        fa = os.path.join(fasta_dir, fasta_name)
        process(fa, output_base_dir, fasta_name.split('.')[0], seq_search_db, templ_search_db)

        
        new_hhr_path = hhr_path
        delete_struct_in_hhr(hhr_path, new_hhr_path, fasta_name[:4])
        
        new_atab_path = atab_path
        delete_struct_in_atab(atab_path, new_atab_path, fasta_name[:4])
    else:
        print('msa info has been extracted')

    # if not fasta_name[:-6]+'.ncaccb.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])):
    #     try:
    #         ncaccb_process(output_base_dir, output_base_dir, fasta_name[:-6])
    #     except Exception as e:
    #         with open('wrong_data.txt', 'a') as f:
    #             f.write('ncaccb_wrong:'+fasta_name)
    #             f.write('\n')
    #             f.write(e)
    #             f.write('\n')

    # else:
    #     print('ncaccb has been extracted')

    # if not fasta_name[:-6]+'.dis_angle.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])) or \
    #         fasta_name[:-6]+'.mask.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])):
    #     try:
    #         dis_angle_process(output_base_dir, output_base_dir, fasta_name[:-6])
    #     except Exception as e:
    #         with open('wrong_data.txt', 'a') as f:
    #             f.write('dis_angle_wrong:'+fasta_name)
    #             f.write('\n')
    #             f.write(e)
    #             f.write('\n')
    # else:
    #     print('dis angle have been extracted')   


def extract_msa_templ(fasta_dir, output_base_dir, seq_search_db, templ_search_db):
    
    for i, fasta_name in enumerate(tqdm(list(os.listdir(fasta_dir)))):
        print('extract %d protein msa'%i)
        # extract_msa_templ_func(fasta_dir, fasta_name, output_base_dir, seq_search_db, templ_search_db)
        p = Pool(4)

        p.apply_async(extract_msa_templ_func, (fasta_dir, fasta_name, output_base_dir, seq_search_db, templ_search_db))

        p.close()
        p.join()


def extract_msa_templ_bp(fasta_dir, output_base_dir, seq_search_db, big_seq_search_db, templ_search_db):

    for i, fasta_name in enumerate(tqdm(list(os.listdir(fasta_dir)))):
        print('extract %d protein msa'%i)
        hhr_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_.hhr")
        atab_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_.atab")
        new_hhr_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_new.hhr")
        new_atab_path = os.path.join(output_base_dir, fasta_name[:-6], "t000_new.atab")
        if not (os.path.exists(hhr_path) and os.path.exists(atab_path)):
            print(fasta_name.split('.')[0])
            fa = os.path.join(fasta_dir, fasta_name)
            process(fa, output_base_dir, fasta_name.split('.')[0], seq_search_db, big_seq_search_db, templ_search_db)

            
            #new_hhr_path = hhr_path
            delete_struct_in_hhr(hhr_path, new_hhr_path, fasta_name[:4])
            
            #new_atab_path = atab_path
            delete_struct_in_atab(atab_path, new_atab_path, fasta_name[:4])
        else:
            print('msa info has been extracted')

        if not fasta_name[:-6]+'.ncaccb.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])):
            ncaccb_process(output_base_dir, output_base_dir, fasta_name[:-6])
        else:
            print('ncaccb has been extracted')

        if not fasta_name[:-6]+'.dis_angle.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])) or \
                fasta_name[:-6]+'.mask.npy' in os.listdir(os.path.join(output_base_dir, fasta_name[:-6])):
            dis_angle_process(output_base_dir, output_base_dir, fasta_name[:-6])
        else:
            print('dis angle have been extracted')  

if __name__ == '__main__':
    in_fa_dir = sys.argv[1]
    in_list = list(os.listdir(in_fa_dir))
    output_base_dir = sys.argv[2]
    # print(in_fa_dir, in_list, output_base_dir)
    seq_search_db = sys.argv[3]
    big_seq_search_db = sys.argv[4]
    templ_search_db = sys.argv[5]
    # p = Pool(int(sys.argv[6]))
    for i, line in enumerate(in_list):
        print(line)
        # fa = os.path.join(in_fa_dir, line.strip(), line.strip() + ".fasta")
        start_time = time.time()
        fa = os.path.join(in_fa_dir, line)
        # print(fa)
        process(fa, output_base_dir, line[:-6], seq_search_db, big_seq_search_db, templ_search_db)
        # p.apply_async(extract_msa_templ_func, (in_fa_dir, line, output_base_dir, seq_search_db, big_seq_search_db, templ_search_db, i))
        end_time = time.time()
        # if state:
        #     break
        with open('orphan_msa_time.txt','a') as f:
            f.write(line.strip()+','+str(end_time-start_time)+'\n')

    # p.close()
    # p.join()
        



