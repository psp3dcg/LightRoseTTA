import os




def delete_struct_in_hhr(file_path, write_path, protein_name):
	with open(file_path) as f:
		hhr_file = f.readlines()
	protein_name = protein_name.lower()
	new_hhr_file = []
	delete_protein_number = []
	del_flag = False
	for line in hhr_file:
		if line[:10] == 'Confidence':
			del_flag = False
			continue

		if line[4:8] == protein_name:
			delete_protein_number.append(int(line[:3]))
			continue

		if line[:3] == 'No ' and int(line[3:]) in delete_protein_number:
			del_flag = True

		if del_flag:
			continue



		new_hhr_file.append(line)

	with open(write_path, 'w') as f:
		for line in new_hhr_file:
			f.write(line)

def delete_struct_in_atab(file_path, write_path, protein_name):
	with open(file_path) as f:
		atab_file = f.readlines()
	protein_name = protein_name.lower()
	new_atab_file = []
	del_flag = False
	for line in atab_file:
		if line[:1] == '>':
			del_flag = False

		if line[1:5] == protein_name:
			del_flag = True
			continue

		if del_flag:
			continue

		new_atab_file.append(line)

	with open(write_path, 'w') as f:
		for line in new_atab_file:
			f.write(line)


def main():

	# protein_name = "1lq7"
	# file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.hhr"
	# write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.hhr"

	# delete_struct_in_hhr(file_path, write_path, protein_name)

	# file_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_.atab"
	# write_path = "/data/wxd_workspace/LightFold/LightFold-code/Orphan25_2020_data/raw/6LH8_A/t000_new_.atab"

	# delete_struct_in_atab(file_path, write_path, protein_name)
	name_dict={'T1024':'6t1z','T1025':'6uv6','T1026':'6s44','T1027':'7d2o','T1029':'6uf2','T1030':'6poo',
				'T1031':'6vr4','T1032':'6n64','T1033':'6vr4','T1034':'6tmm','T1035':'6vr4','T1036':'6vn1','T1037':'6vr4','T1038':'6ya2',
				'T1039':'6vr4','T1040':'6vr4','T1041':'6vr4','T1042':'6vr4','T1043':'6vr4','T1046':'6px4',
				'T1047':'7bgl','T1049':'6y4f','T1053':'7m7a','T1054':'6v4v','T1055':'6zyc','T1056':'6yj1',
				'T1057':'7m6b','T1058':'7abw','T1064':'7jtl','T1065':'7m5f','T1070':'7rej','T1074':'7oc9','T1082':'7cn6',
				'T1089':'7mhu','T1090':'7k7w','T1091':'7w6b','T1092':'7um1','T1093':'7um1','T1094':'7um1',
				'T1095':'7um1','T1099':'6ygh',}
	file_path = "/media/user/protein_data_6/dataset/casp14_revised_domain_data/raw/"
	write_path = "/media/user/protein_data_6/dataset/casp14_revised_domain_data/raw/"
	for name in os.listdir(file_path):
		print(name)
		# import pdb
		# pdb.set_trace()
		# if name[:5] not in name_dict.keys():
		# 	continue
		# protein_name = name_dict[name[:5]]
		# # protein_name = name.split('_')[0].lower()
		# hhr_path = os.path.join(file_path, name, "t000_.hhr")
		# new_hhr_path = os.path.join(file_path, name, "t000_new.hhr")
		# delete_struct_in_hhr(hhr_path, new_hhr_path, protein_name)

		# atab_path = os.path.join(file_path, name, "t000_.atab")
		# new_atab_path = os.path.join(file_path, name, "t000_new.atab")
		# delete_struct_in_atab(atab_path, new_atab_path, protein_name)


		hhr_path = os.path.join(file_path, name, "t000_.hhr")
		hhr_ori_path = os.path.join(file_path, name, "t000_ori.hhr")
		hhr_new_path = os.path.join(file_path, name, "t000_new.hhr")
		if os.path.exists(hhr_new_path):
			os.rename(hhr_path, hhr_ori_path)
			os.rename(hhr_new_path, hhr_path)

		atab_path = os.path.join(file_path, name, "t000_.atab")
		atab_ori_path = os.path.join(file_path, name, "t000_ori.atab")
		atab_new_path = os.path.join(file_path, name, "t000_new.atab")
		if os.path.exists(atab_new_path):
			os.rename(atab_path, atab_ori_path)
			os.rename(atab_new_path, atab_path)		

if __name__ == '__main__':
	main()
