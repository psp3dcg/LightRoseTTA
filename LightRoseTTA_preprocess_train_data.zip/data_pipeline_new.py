'''
process raw data
'''
import os
import copy
import torch
import numpy as np
from Bio import SeqIO
from torch_geometric.data import Data
from torch_geometric.data import Dataset

from utils.ffindex import *
from utils.parsers import *
from utils.kinematics import xyz_to_t2d






class Protein_Dataset(Dataset):
    def __init__(self, root, test_mode=False, pre_filter=None, pre_transform=None):
        '''init func

        Input:
            - root(str):test data path 
            - test_mode(str):train or test mode
            - pre_filter:filter process
            - pre_transform:transform process
        '''
        self.raw_file_path = os.path.join(root, 'raw')
        self.processed_file_path = os.path.join(root, 'processed')
        self.root = root

        # for test
        self.test_mode = test_mode
        self.fasta_str_list = []
        self.all_atom_list = []
        self.protein_name_list = []

        self.pre_filter = pre_filter
        self.pre_transform = pre_transform

        super(Protein_Dataset, self).__init__(root, pre_filter, pre_transform)

        if not os.path.exists(self.processed_file_path) or len(os.listdir(self.processed_file_path)) < self.len():
            self.data_num_features, self.data_num_classes = self.process()
        else:
            if not self.test_mode:
                self.data_num_features = self.get(0).x.shape[1]
                self.data_num_classes = self.get(0).pos.shape[1]
            else:
                self.data_num_features = self.get(0).x.shape[1]
                self.data_num_classes = 3

    @property
    def raw_file_names(self):
        '''read raw file names

        Output:
            - file_path_list(list):raw file list
        '''
        file_name_list = os.listdir(self.raw_file_path)
        file_path_list = []
        for name in file_name_list:
            file_path_list.append(os.path.join(self.raw_file_path, name))

        return file_path_list

    @property
    def processed_file_names(self):
        '''generate processed file names

        Output:
            - data_pt_list(list):processed file list
        '''
        if not os.path.exists(self.processed_file_path):
            os.mkdir(self.processed_file_path)
        data_pt_list = []
        for i in range(len(os.listdir(self.raw_file_path))):
            data_pt_list.append('data_{}.pt'.format(i))
        return data_pt_list

    def download(self):
        # Download to `self.raw_dir`.
        pass


    # def process(self):
    #     # Read data into huge `Data` list.
    #     '''process raw data
    #     '''

        #test_mode
        # if self.test_mode:
        #     new_CA_atom_index_list = torch.tensor(CA_atom_index_list, dtype = torch.long)
        #     data = Data(x=new_x, edge_index=new_edge_index, edge_attr = new_edge_attr, CA_atom_index=new_CA_atom_index_list,
        #                     msa = new_msa, xyz_t = new_xyz_t, t0d = new_t0d, t1d = new_t1d, protein_name = protein_name)

        # if self.pre_filter is not None and not self.pre_filter(data):
        #     continue

        # if self.pre_transform is not None:
        #     data = self.pre_transform(data)

        # torch.save(data, os.path.join(self.processed_file_path, 'data_{}.pt'.format(i)))


        # data_num_features = node_dim
        # data_num_classes  = pos_dim

        # return data_num_features, data_num_classes

    def len(self):
        return len(self.processed_file_names)

    def get(self, idx):
        data = torch.load(os.path.join(self.processed_file_path, 'data_{}.pt'.format(idx)))
        return data
