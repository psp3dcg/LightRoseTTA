import os

def read_coor_file(file_path, protein_name, coor_file_name):
    new_atom_coor = []
    with open(os.path.join(file_path, protein_name, coor_file_name)) as f:
        atom_coor = f.readlines()
    for coor in atom_coor:
        new_coor = coor[:-1].split(' ')
        element_list = []
        for element in new_coor[-1].split(','):
            new_element = float(element)
            element_list.append(new_element)
        new_coor[-1] = element_list
        new_atom_coor.append(new_coor)
    return new_atom_coor

def coor_minus(coor_1, coor_2):
    result_coor = []
    if len(coor_1) == len(coor_2):
        for i in range(len(coor_1)):
            coor = coor_2[i] - coor_1[i]
            result_coor.append(coor)
    return result_coor

def normalize_the_center(atom_coor_list):

    base_coor = atom_coor_list[0][-1]

    for i in range(len(atom_coor_list)):
        atom_coor_list[i][-1] = coor_minus(base_coor, atom_coor_list[i][-1])
    return atom_coor_list

def write_coor(write_path, protein_name, coor_file_name, atom_coor_list):
    with open(os.path.join(write_path, protein_name, coor_file_name), 'w') as f:
        for atom_coor in atom_coor_list:
            atom_line = atom_coor[0]+' '
            for coor in atom_coor[-1]:
                atom_line += str(coor)
                atom_line += ','
            atom_line = atom_line[:-1]+'\n'
            f.write(atom_line)

def norm_center(file_path):
    
    write_path = file_path

    coor_file_name = "pdb_coor.txt"
    write_file_name = "normal_pdb_coor.txt"

    protein_name_list = os.listdir(file_path)

    for protein_name in protein_name_list:
        print("-----protein name:%s------"%protein_name)
        if not os.path.exists(os.path.join(file_path, protein_name, coor_file_name)):
            continue
        atom_coor_list = read_coor_file(file_path, protein_name, coor_file_name)
        atom_coor_list = normalize_the_center(atom_coor_list)
        write_coor(write_path, protein_name, write_file_name, atom_coor_list)

if __name__ == "__main__":
    file_path = r"F:\dataset\protein_data\test_for_rf\output_2"
    norm_center(file_path)


