import os
from Bio.PDB.PDBParser import PDBParser




res_name_map = {"ALA": "A",
            "CYS": "C",
            "ASP": "D",
            "GLU": "E",
            "PHE": "F",
            "GLY": "G",
            "HIS": "H",
            "ILE": "I",
            "LYS": "K",
            "LEU": "L",
            "MET": "M",
            "ASN": "N",
            "PRO": "P",
            "GLN": "Q",
            "ARG": "R",
            "SER": "S",
            "THR": "T",
            "VAL": "V",
            "TRP": "W",
            "TYR": "Y"}

atom_num_map = {"A": 5,
                "C": 6,
                "D": 8,
                "E": 9,
                "F": 11,
                "G": 4,
                "H": 10,
                "I": 8,
                "K": 9,
                "L": 8,
                "M": 8,
                "N": 8,
                "P": 7,
                "Q": 9,
                "R": 11,
                "S": 6,
                "T": 7,
                "V": 7,
                "W": 14,
                "Y": 12}

#amino acid atom name
atom_name_map = {"A": ['N','CA','C','O','CB'],
                "C": ['N','CA','C','O','CB','SG'],
                "D": ['N','CA','C','O','CB','CG','OD1','OD2'],
                "E": ['N','CA','C','O','CB','CG','CD','OE1','OE2'],
                "F": ['N','CA','C','O','CB','CG','CD1','CD2','CE1','CE2','CZ'],
                "G": ['N','CA','C','O'],
                "H": ['N','CA','C','O','CB','CG','ND1','CD2','CE1','NE2'],
                "I": ['N','CA','C','O','CB','CG1','CG2','CD1'],
                "K": ['N','CA','C','O','CB','CG','CD','CE','NZ'],
                "L": ['N','CA','C','O','CB','CG','CD1','CD2'],
                "M": ['N','CA','C','O','CB','CG','SD','CE'],
                "N": ['N','CA','C','O','CB','CG','OD1','ND2'],
                "P": ['N','CA','C','O','CB','CG','CD'],
                "Q": ['N','CA','C','O','CB','CG','CD','OE1','NE2'],
                "R": ['N','CA','C','O','CB','CG','CD','NE','CZ','NH1','NH2'],
                "S": ['N','CA','C','O','CB','OG'],
                "T": ['N','CA','C','O','CB','OG1','CG2'],
                "V": ['N','CA','C','O','CB','CG1','CG2'],
                "W": ['N','CA','C','O','CB','CG','CD1','CD2','NE1','CE2','CE3','CZ2','CZ3','CH2'],
                "Y": ['N','CA','C','O','CB','CG','CD1','CD2','CE1','CE2','CZ','OH']}


def parse_pdb(pdb_name, file_path, generate_mode):
    
    
    # p = PDBParser(PERMISSIVE=1)
    # struct_id = "qq"
    atom_name_list = []
    atom_coor_list = []

    

    backbone_atom_name = ("N", "CA", "C")

    try:
        # s = p.get_structure(struct_id, file_path)
        parser = PDBParser().get_structure(pdb_name, file_path)
    except:
        print('cannot get struct from pdb')
        return [], []

    # model = s[0]
    for chain in parser.get_chains():
        # try:
        #     # chain = model[seq_id]
        #     chain = parser[]
        # except:
        #     print('cannot get chain {} from pdb'.format(seq_id))
        #     return [], []
        num_node = 0
        for ch in chain:
            residue = chain[ch.get_id()]
            # print(ch.get_id()[0])
            if ch.get_id()[0] != " ":
                continue
            #print(name_map[residue.get_resname().upper()],end="")
            short_res_name = res_name_map[residue.get_resname().upper()]
            standard_atom_len = atom_num_map[short_res_name]
            standard_atom_name_list = atom_name_map[short_res_name]
            atom_idx = 0
            res_atom_info_dict = {}
            for res in residue:
                atom = residue[res.get_id()]
                atom_list = str(atom).split(' ')
                new_atom = atom_list[1]
                atom_name = str(new_atom)[0]
                atom_name_with_alpha = str(new_atom)[:-1]
                
                if generate_mode == 'backbone':
                    if atom_name_with_alpha not in backbone_atom_name:
                        continue
                # print('atom_name:',atom_name_with_alpha)

                if atom_name != "H" and atom_name != "G":
                    #print(atom)
                    #print(atom.get_vector())
                    coor_list = list(atom.get_vector())
                    coor_str = str(coor_list[0])
                    for i in range(1, len(coor_list)):
                        coor_str += ","
                        coor_str += str(coor_list[i])
                    res_atom_info_dict[atom_name_with_alpha] = coor_str
                    
                    num_node += 1
                    atom_idx += 1

            real_atom_name_list = res_atom_info_dict.keys()
            if len(real_atom_name_list) != standard_atom_len:
                for name in standard_atom_name_list:
                    if name not in real_atom_name_list:
                        res_atom_info_dict[name] = "0.0,0.0,0.0"
            
            for name in standard_atom_name_list:
                atom_name_list.append(name)
                atom_coor_list.append(res_atom_info_dict[name])

        
    print()
    #print(num_node)
    #print(atom_name_list)
    return atom_name_list, atom_coor_list

def write_pos_to_file(write_path, atom_name_list, atom_coor_list):
    write_name = "pdb_coor.txt"
    if not os.path.exists(write_path):
        os.mkdir(write_path)
    with open(os.path.join(write_path, write_name), 'w') as f:
        for i in range(len(atom_coor_list)):
            f.write(atom_name_list[i])
            f.write(' ')
            f.write(atom_coor_list[i])
            f.write('\n')

def read_seq_file(file_path):
    seq_list = []
    try:
        with open(file_path, 'r') as f:
            seq_file = f.readlines()
        for res in seq_file:
            seq_list.append(res.split(' ')[0].replace("\n", ""))
    except:
        print("%s does not exist"%file_path)


    return seq_list

def check_atom_seq(protein_seq_1, protein_seq_2):
    for i, res in enumerate(protein_seq_1):
        if res != protein_seq_2[i]:
            print(i)


if __name__ == '__main__':
    protein_name = "1OVU"
    name_map = init_name_map()

    file_path = os.path.join("D:\PycharmProjects\protein_structure\pdb", protein_name+".pdb")
    write_path = os.path.join("D:\PycharmProjects\protein_structure\output", protein_name+"_1")
    seq_id = protein_name[-3]
    atom_name_list, atom_coor_list = parse_pdb(file_path, 'train', seq_id)
    write_to_file(write_path, atom_name_list, atom_coor_list)

    seq_path_1 = os.path.join("D:\PycharmProjects\protein_structure\output", protein_name + "_1", "node_label.txt")
    seq_path_2 = os.path.join("D:\PycharmProjects\protein_structure\output", protein_name + "_1", "pdb_coor.txt")

    seq_1 = read_seq_file(seq_path_1)
    seq_2 = read_seq_file(seq_path_2)

    check_atom_seq(seq_1, seq_2)



# residue = chain[4]
# atom = residue["CA"]
# atom_2 = residue["CB"]

# print(atom - atom_2)
# for res in residues:
#     print(res)
#     ca1 = res[]
#     for atom in res:
#         print(atom)
#         print(atom)