import os

def download_homolog_datasets():
    print('Downloading the homologous datasets...')

    seq_search_db_link = "http://wwwuser.gwdg.de/~compbiol/uniclust/2020_06/UniRef30_2020_06_hhsuite.tar.gz"
    seq_download_cmd = "wget "+seq_search_db_link
    uncompress_seq_cmd = "tar xfz UniRef30_2020_06_hhsuite.tar.gz -C ./UniRef30_2020_06"
    os.system(seq_download_cmd)
    os.system(uncompress_seq_cmd)

    templ_search_db_link = "https://files.ipd.uw.edu/pub/RoseTTAFold/pdb100_2021Mar03.tar.gz"
    templ_download_cmd = "wget "+templ_search_db_link
    uncompress_templ_cmd = "tar xfz pdb100_2021Mar03.tar.gz"
    os.system(templ_download_cmd)
    os.system(uncompress_templ_cmd)

    print('Downloading process is finished...')

if __name__ == '__main__':
    download_homolog_datasets()